import sys
sys.path.append('/home/pi/Desktop/ProfMate/')
import MainController
import database

MainController.registration_controller()
